import WeilSignedPrimeEventualBridgeV1

/-! Every single signed prime-correlation series is a finite sum, for every
packet and every real shift. The arithmetic boundedness criterion cannot rely
on Lean's totalization of a divergent series. No translation-uniform bound is
claimed. -/
open Set Function MeasureTheory Complex
open scoped ComplexConjugate BigOperators
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilSignedPrimeFiniteSupportV1
open AEGIS.WeilWidthArchCorrelationV25
open AEGIS.WeilSeparatedArchBridgeV31
open AEGIS.WeilSignedKernelReductionV1
open AEGIS.WeilWindowExhaustionV1

def SignedPrimeTermV1 (g : WeilCompactSmoothGV1) (d : ℝ) (n : ℕ) : ℂ :=
  ((ArithmeticFunction.vonMangoldt (n + 1) : ℝ) : ℂ) *
    (Real.exp (-Real.log ((n + 1 : ℕ) : ℝ) / 2) : ℂ) *
      logCorrelationV25 g (-Real.log ((n + 1 : ℕ) : ℝ) + d)

theorem signed_prime_term_cutoff_v1 (g : WeilCompactSmoothGV1) (d : ℝ) :
    ∃ N : ℕ, ∀ n : ℕ, N ≤ n → SignedPrimeTermV1 g d n = 0 := by
  obtain ⟨L, _, hw⟩ := logLift_has_finite_window_v1 g
  obtain ⟨N, hN⟩ := exists_nat_gt (Real.exp (d + 2 * L))
  refine ⟨N, ?_⟩
  intro n hn
  have hnR : Real.exp (d + 2 * L) < ((n + 1 : ℕ) : ℝ) := by
    apply lt_of_lt_of_le hN
    exact_mod_cast hn.trans (Nat.le_succ n)
  have hlog : d + 2 * L < Real.log ((n + 1 : ℕ) : ℝ) := by
    have h := Real.log_lt_log (Real.exp_pos (d + 2 * L)) hnR
    simpa only [Real.log_exp] using h
  have hc : logCorrelationV25 g (-Real.log ((n + 1 : ℕ) : ℝ) + d) = 0 :=
    logCross_zero_outside g g (-L) L (-L) L _ hw hw (Or.inl (by linarith))
  simp only [SignedPrimeTermV1, hc, mul_zero]

theorem signed_prime_term_hasFiniteSupport_v1 (g : WeilCompactSmoothGV1) (d : ℝ) :
    Function.HasFiniteSupport (SignedPrimeTermV1 g d) := by
  classical
  obtain ⟨N, hN⟩ := signed_prime_term_cutoff_v1 g d
  refine (Finset.range N).finite_toSet.subset ?_
  intro n hn
  change SignedPrimeTermV1 g d n ≠ 0 at hn
  simp only [Finset.mem_coe, Finset.mem_range]
  by_contra hnot
  exact hn (hN n (Nat.le_of_not_gt hnot))

theorem signed_prime_term_summable_v1 (g : WeilCompactSmoothGV1) (d : ℝ) :
    Summable (SignedPrimeTermV1 g d) :=
  summable_of_hasFiniteSupport (signed_prime_term_hasFiniteSupport_v1 g d)

theorem signed_prime_correlation_eq_finite_sum_v1 (g : WeilCompactSmoothGV1) (d : ℝ) :
    ∃ N : ℕ, SignedPrimeCorrelationV1 g d = ∑ n ∈ Finset.range N, SignedPrimeTermV1 g d n := by
  obtain ⟨N, hN⟩ := signed_prime_term_cutoff_v1 g d
  refine ⟨N, ?_⟩
  change (∑' n : ℕ, SignedPrimeTermV1 g d n) = _
  apply tsum_eq_sum
  intro n hn
  exact hN n (Nat.le_of_not_gt (by simpa using hn))

end AEGIS.WeilSignedPrimeFiniteSupportV1

#print axioms AEGIS.WeilSignedPrimeFiniteSupportV1.signed_prime_term_cutoff_v1
#print axioms AEGIS.WeilSignedPrimeFiniteSupportV1.signed_prime_term_hasFiniteSupport_v1
#print axioms AEGIS.WeilSignedPrimeFiniteSupportV1.signed_prime_term_summable_v1
#print axioms AEGIS.WeilSignedPrimeFiniteSupportV1.signed_prime_correlation_eq_finite_sum_v1
