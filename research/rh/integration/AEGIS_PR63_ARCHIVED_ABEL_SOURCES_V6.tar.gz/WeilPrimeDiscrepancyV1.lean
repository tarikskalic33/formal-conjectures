import WeilPrimeAbelReductionV1
import Mathlib.MeasureTheory.Integral.IntervalIntegral.IntegrationByParts

open Set Function MeasureTheory Complex
open scoped BigOperators ContDiff
set_option autoImplicit false
noncomputable section
namespace AEGIS.WeilPrimeDiscrepancyV1
open AEGIS.WeilPrimeAbelReductionV1
open AEGIS.WeilWidthArchCorrelationV25
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilSeparatedArchBridgeV31
open AEGIS.WeilSignedKernelReductionV1
open AEGIS.WeilSignedPrimeFiniteSupportV1
open AEGIS.WeilWindowExhaustionV1

def PrimeDiscrepancyV1 (x : ℝ) : ℂ := ChebyshevV1 x - (x : ℂ)

theorem primeWeight_integral_zero_v1 (g : WeilCompactSmoothGV1)
    (hm : WeilMomentConditionsV1 g) (d : ℝ) :
    (∫ x in Set.Ioi (0 : ℝ), PrimeWeightV1 g d x) = 0 := by
  obtain ⟨L, _, hw⟩ := logLift_has_finite_window_v1 g
  have hz := logCross_minus_moment_zero g g (-L) L (-L) L hw hw hm
  change (∫ t : ℝ, (Real.exp (-t / 2) : ℂ) * logCorrelationV25 g t) = 0 at hz
  rw [integral_exp_substitution_complex]
  have heq : (fun u : ℝ => (Real.exp u) • PrimeWeightV1 g d (Real.exp u)) =
      fun u => (Real.exp (d / 2) : ℂ) *
        ((Real.exp (-(d - u) / 2) : ℂ) * logCorrelationV25 g (d - u)) := by
    funext u
    simp only [PrimeWeightV1, Real.log_exp, Complex.real_smul]
    rw [← mul_assoc, ← mul_assoc, ← Complex.ofReal_mul, ← Complex.ofReal_mul,
      ← Real.exp_add, ← Real.exp_add]
    congr 2
    ring
  have hs := integral_sub_left_eq_self
    (fun t : ℝ => (Real.exp (-t / 2) : ℂ) * logCorrelationV25 g t) volume d
  rw [heq, integral_const_mul, hs, hz, mul_zero]

theorem primeWeight_zero_below_one_v1 (g : WeilCompactSmoothGV1)
    (L d x : ℝ) (hw : LogSupportIn g (-L) L) (hd : 2 * L < d)
    (hx : 0 < x) (hx1 : x ≤ 1) : PrimeWeightV1 g d x = 0 := by
  have hl : Real.log x ≤ 0 := Real.log_nonpos hx.le hx1
  have hc := logCross_zero_outside g g (-L) L (-L) L (d - Real.log x)
    hw hw (Or.inr (by linarith))
  simpa [PrimeWeightV1, logCorrelationV25, AEGIS.WeilThreeBlockCrossPrimeV28.logCrossV28]
    using congrArg (fun z : ℂ => (Real.exp (-Real.log x / 2) : ℂ) * z) hc

theorem primeWeight_interval_integral_zero_v1 (g : WeilCompactSmoothGV1)
    (hm : WeilMomentConditionsV1 g) (L d : ℝ) (N : ℕ)
    (hw : LogSupportIn g (-L) L) (hd : 2 * L < d)
    (hupper : ∀ x : ℝ, (N : ℝ) ≤ x → PrimeWeightV1 g d x = 0) :
    (∫ x in Set.Ioc (1 : ℝ) N, PrimeWeightV1 g d x) = 0 := by
  rw [← primeWeight_integral_zero_v1 g hm d]
  symm
  apply setIntegral_eq_of_subset_of_forall_sdiff_eq_zero measurableSet_Ioi
    (fun x hx => lt_trans zero_lt_one hx.1)
  intro x hx
  by_cases hx1 : x ≤ 1
  · exact primeWeight_zero_below_one_v1 g L d x hw hd hx.1 hx1
  · apply hupper x
    have h := hx.2
    simp only [Set.mem_Ioc, not_and] at h
    exact (lt_of_not_ge (h (lt_of_not_ge hx1))).le

/-- Exact subtraction of the continuum density. All hypotheses are support and
actual moment data; none is an unproved arithmetic estimate. -/
theorem prime_correlation_discrepancy_of_cutoff_v1
    (g : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 g)
    (L d : ℝ) (N : ℕ) (hw : LogSupportIn g (-L) L) (hd : 2 * L < d)
    (hN : 1 ≤ N) (hupper : ∀ x : ℝ, (N : ℝ) ≤ x → PrimeWeightV1 g d x = 0) :
    SignedPrimeCorrelationV1 g d =
      -(∫ x in Set.Ioc (1 : ℝ) N,
        deriv (PrimeWeightV1 g d) x * PrimeDiscrepancyV1 x) := by
  have hab : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hdz : ∀ x ∈ Set.Icc (1 : ℝ) N, DifferentiableAt ℝ (PrimeWeightV1 g d) x := by
    intro x hx
    exact (primeWeight_contDiffAt_v1 g d x (lt_of_lt_of_le zero_lt_one hx.1)).differentiableAt (by simp)
  have hc : ContinuousOn (deriv (PrimeWeightV1 g d)) (Set.Icc (1 : ℝ) N) := by
    intro x hx
    exact ((primeWeight_contDiffAt_v1 g d x (lt_of_lt_of_le zero_lt_one hx.1)).derivWithin
      (m := 0) (by simp)).continuousAt.continuousWithinAt
  have hi : IntegrableOn (deriv (PrimeWeightV1 g d)) (Set.Icc (1 : ℝ) N) volume := hc.integrableOn_Icc
  have hii : IntervalIntegrable (deriv (PrimeWeightV1 g d)) volume 1 N :=
    (intervalIntegrable_iff_integrableOn_Icc_of_le hab).mpr hi
  have hzN := hupper N le_rfl
  have hz1 := primeWeight_zero_below_one_v1 g L d 1 hw hd zero_lt_one le_rfl
  have hmean := primeWeight_interval_integral_zero_v1 g hm L d N hw hd hupper
  have hdW : ∀ x ∈ Set.uIcc (1 : ℝ) N,
      HasDerivAt (PrimeWeightV1 g d) (deriv (PrimeWeightV1 g d) x) x := by
    intro x hx
    rw [Set.uIcc_of_le hab] at hx
    exact (hdz x hx).hasDerivAt
  have hparts := intervalIntegral.integral_mul_deriv_eq_deriv_mul
    (u := fun x : ℝ => (x : ℂ)) (u' := fun _ => (1 : ℂ))
    (fun x _ => (hasDerivAt_id x).ofReal_comp) hdW intervalIntegrable_const hii
  have hlin : (∫ x in Set.Ioc (1 : ℝ) N,
      deriv (PrimeWeightV1 g d) x * (x : ℂ)) = 0 := by
    simpa only [intervalIntegral.integral_of_le hab, hzN, hz1,
      mul_zero, zero_mul, sub_self, one_mul, hmean, sub_zero, mul_comm] using hparts
  have hcut : ∀ n : ℕ, N ≤ n → SignedPrimeTermV1 g d n = 0 := by
    intro n hn
    have hx : (N : ℝ) ≤ ((n + 1 : ℕ) : ℝ) := by exact_mod_cast hn.trans (Nat.le_succ n)
    have hz := hupper ((n + 1 : ℕ) : ℝ) hx
    have heq : SignedPrimeTermV1 g d n =
        (ArithmeticFunction.vonMangoldt (n + 1) : ℂ) * PrimeWeightV1 g d ((n + 1 : ℕ) : ℝ) := by
      simp only [SignedPrimeTermV1, PrimeWeightV1]
      rw [show -Real.log ((n + 1 : ℕ) : ℝ) + d = d - Real.log ((n + 1 : ℕ) : ℝ) by ring]
      ring
    rw [heq, hz, mul_zero]
  have ha := sum_mul_eq_sub_integral_mul₀' (fun n : ℕ =>
    (ArithmeticFunction.vonMangoldt n : ℂ)) (by simp) N hdz hi
  have hS : SignedPrimeCorrelationV1 g d =
      -(∫ x in Set.Ioc (1 : ℝ) N, deriv (PrimeWeightV1 g d) x * ChebyshevV1 x) := by
    rw [prime_correlation_eq_finite_weight_sum_v1 g d N hcut, ha, hzN, zero_mul, zero_sub]
    rfl
  have hpsi : IntegrableOn (fun x => deriv (PrimeWeightV1 g d) x * ChebyshevV1 x)
      (Set.Ioc (1 : ℝ) N) volume :=
    (integrableOn_mul_sum_Icc (fun n : ℕ => (ArithmeticFunction.vonMangoldt n : ℂ))
      zero_le_one hi).mono_set Set.Ioc_subset_Icc_self
  have hxi : IntegrableOn (fun x => deriv (PrimeWeightV1 g d) x * (x : ℂ))
      (Set.Ioc (1 : ℝ) N) volume :=
    ((hc.mul Complex.continuous_ofReal.continuousOn).integrableOn_Icc).mono_set Set.Ioc_subset_Icc_self
  rw [hS]
  unfold PrimeDiscrepancyV1
  simp_rw [mul_sub]
  rw [integral_sub hpsi hxi, hlin, sub_zero]

/-- Every actual moment-zero packet admits the discrepancy representation for
all sufficiently separated shifts. The cutoff is proved to exist. -/
theorem prime_correlation_discrepancy_v1 (g : WeilCompactSmoothGV1)
    (hm : WeilMomentConditionsV1 g) :
    ∃ L : ℝ, 0 < L ∧ ∀ d : ℝ, 2 * L < d →
      ∃ N : ℕ, 1 ≤ N ∧
        (∀ x : ℝ, (N : ℝ) ≤ x → PrimeWeightV1 g d x = 0) ∧
        SignedPrimeCorrelationV1 g d =
          -(∫ x in Set.Ioc (1 : ℝ) N,
            deriv (PrimeWeightV1 g d) x * PrimeDiscrepancyV1 x) := by
  obtain ⟨L, hL, hw⟩ := logLift_has_finite_window_v1 g
  refine ⟨L, hL, ?_⟩
  intro d hd
  obtain ⟨N, hN⟩ := exists_nat_gt (max 1 (Real.exp (d + 2 * L)))
  have hN1 : (1 : ℝ) < N := lt_of_le_of_lt (le_max_left _ _) hN
  have hNnat : 1 ≤ N := by exact_mod_cast hN1.le
  have hupper : ∀ x : ℝ, (N : ℝ) ≤ x → PrimeWeightV1 g d x = 0 := by
    intro x hx
    apply primeWeight_zero_of_large_log_v1 g L d x hw
    have he : Real.exp (d + 2 * L) < x :=
      (lt_of_le_of_lt (le_max_right _ _) hN).trans_le hx
    simpa using Real.log_lt_log (Real.exp_pos _) he
  exact ⟨N, hNnat, hupper,
    prime_correlation_discrepancy_of_cutoff_v1 g hm L d N hw hd hNnat hupper⟩

end AEGIS.WeilPrimeDiscrepancyV1
#print axioms AEGIS.WeilPrimeDiscrepancyV1.primeWeight_integral_zero_v1
#print axioms AEGIS.WeilPrimeDiscrepancyV1.primeWeight_zero_below_one_v1
#print axioms AEGIS.WeilPrimeDiscrepancyV1.primeWeight_interval_integral_zero_v1

#print axioms AEGIS.WeilPrimeDiscrepancyV1.prime_correlation_discrepancy_of_cutoff_v1
#print axioms AEGIS.WeilPrimeDiscrepancyV1.prime_correlation_discrepancy_v1
