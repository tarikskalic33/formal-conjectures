import WeilPrimeDiscrepancyV1
import Mathlib.NumberTheory.Chebyshev

open Set Function MeasureTheory Complex
open scoped BigOperators ContDiff
set_option autoImplicit false
noncomputable section
namespace AEGIS.WeilPrimeDiscrepancyEstimateV1
open AEGIS.WeilPrimeAbelReductionV1
open AEGIS.WeilPrimeDiscrepancyV1
open AEGIS.WeilWidthArchCorrelationV25
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilSignedKernelReductionV1

/-- The step function is exactly Mathlib's actual Chebyshev psi. -/
theorem chebyshev_eq_mathlib_v1 (x : ℝ) :
    ChebyshevV1 x = (Chebyshev.psi x : ℂ) := by
  unfold ChebyshevV1 Chebyshev.psi
  push_cast
  rw [Finset.Icc_eq_cons_Ioc (Nat.zero_le _), Finset.sum_cons]
  simp

theorem discrepancy_eq_mathlib_v1 (x : ℝ) :
    PrimeDiscrepancyV1 x = ((Chebyshev.psi x - x : ℝ) : ℂ) := by
  simp [PrimeDiscrepancyV1, chebyshev_eq_mathlib_v1]

theorem primeWeight_deriv_v1 (g : WeilCompactSmoothGV1) (d x : ℝ) (hx : 0 < x) :
    deriv (PrimeWeightV1 g d) x =
      -(Real.exp (-Real.log x / 2) : ℂ) / (x : ℂ) *
        (deriv (logCorrelationV25 g) (d - Real.log x) +
          logCorrelationV25 g (d - Real.log x) / 2) := by
  have hlog := Real.hasDerivAt_log (ne_of_gt hx)
  have hw := ((hlog.neg.div_const 2).exp).ofReal_comp
  have hC := ((correlation_contDiff_v1 g).differentiable (by simp)
    (d - Real.log x)).hasDerivAt
  have hshift := hlog.const_sub d
  have hcomp := hC.scomp x hshift
  have hprod := hw.mul hcomp
  change HasDerivAt (PrimeWeightV1 g d) _ x at hprod
  rw [hprod.deriv]
  simp only [Complex.real_smul, Function.comp_apply, Pi.neg_apply]
  push_cast
  ring

/-- A valid absolute estimate after the exact signed main-term subtraction.
It does not assert that this upper bound is uniform in d. -/
theorem prime_correlation_norm_le_discrepancy_integral_v1
    (g : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 g)
    (L d : ℝ) (N : ℕ)
    (hw : LogSupportIn g (-L) L) (hd : 2 * L < d) (hN : 1 ≤ N)
    (hupper : ∀ x : ℝ, (N : ℝ) ≤ x → PrimeWeightV1 g d x = 0) :
    ‖SignedPrimeCorrelationV1 g d‖ ≤
      ∫ x in Set.Ioc (1 : ℝ) N,
        ‖deriv (PrimeWeightV1 g d) x‖ * |Chebyshev.psi x - x| := by
  rw [prime_correlation_discrepancy_of_cutoff_v1 g hm L d N hw hd hN hupper, norm_neg]
  have h := norm_integral_le_integral_norm
    (μ := volume.restrict (Set.Ioc (1 : ℝ) N))
    (fun x => deriv (PrimeWeightV1 g d) x * PrimeDiscrepancyV1 x)
  simpa only [norm_mul, discrepancy_eq_mathlib_v1, Complex.norm_real, Real.norm_eq_abs] using h

/-- The square-root prime-power correction is not the required psi-x error:
the theta-x term remains exactly present. -/
theorem discrepancy_prime_power_split_v1 (x : ℝ) :
    Chebyshev.psi x - x =
      (Chebyshev.psi x - Chebyshev.theta x) + (Chebyshev.theta x - x) := by ring

/-- The unconditional elementary Mathlib estimate is linear in x. -/
theorem abs_discrepancy_le_linear_v1 (x : ℝ) (hx : 0 ≤ x) :
    |Chebyshev.psi x - x| ≤ (Real.log 4 + 5) * x := by
  have hpsi := Chebyshev.psi_nonneg x
  have hup := Chebyshev.psi_le_const_mul_self hx
  have hl : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  apply abs_le.mpr
  constructor <;> nlinarith

/-- What the existing unconditional Chebyshev bound actually supplies.
The right hand side still depends on d through the scaled weight. -/
theorem prime_correlation_elementary_bound_v1
    (g : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 g)
    (L d : ℝ) (N : ℕ)
    (hw : LogSupportIn g (-L) L) (hd : 2 * L < d) (hN : 1 ≤ N)
    (hupper : ∀ x : ℝ, (N : ℝ) ≤ x → PrimeWeightV1 g d x = 0) :
    ‖SignedPrimeCorrelationV1 g d‖ ≤
      (Real.log 4 + 5) * (∫ x in Set.Ioc (1 : ℝ) N,
        ‖deriv (PrimeWeightV1 g d) x‖ * x) := by
  have hc : ContinuousOn (deriv (PrimeWeightV1 g d)) (Set.Icc (1 : ℝ) N) := by
    intro x hx
    exact ((primeWeight_contDiffAt_v1 g d x (lt_of_lt_of_le zero_lt_one hx.1)).derivWithin
      (m := 0) (by simp)).continuousAt.continuousWithinAt
  have hi : IntegrableOn (fun x => ‖deriv (PrimeWeightV1 g d) x‖ * x)
      (Set.Ioc (1 : ℝ) N) volume :=
    ((hc.norm.mul continuous_id.continuousOn).integrableOn_Icc).mono_set Set.Ioc_subset_Icc_self
  apply (prime_correlation_norm_le_discrepancy_integral_v1 g hm L d N hw hd hN hupper).trans
  rw [← integral_const_mul]
  apply integral_mono_of_nonneg
    (Filter.Eventually.of_forall (fun x => mul_nonneg (norm_nonneg _) (abs_nonneg _)))
    (hi.const_mul (Real.log 4 + 5))
  filter_upwards [ae_restrict_mem measurableSet_Ioc] with x hx
  have hx0 : 0 ≤ x := (lt_trans zero_lt_one hx.1).le
  calc
    ‖deriv (PrimeWeightV1 g d) x‖ * |Chebyshev.psi x - x| ≤
        ‖deriv (PrimeWeightV1 g d) x‖ * ((Real.log 4 + 5) * x) :=
      mul_le_mul_of_nonneg_left (abs_discrepancy_le_linear_v1 x hx0) (norm_nonneg _)
    _ = _ := by ring

end AEGIS.WeilPrimeDiscrepancyEstimateV1
#print axioms AEGIS.WeilPrimeDiscrepancyEstimateV1.chebyshev_eq_mathlib_v1
#print axioms AEGIS.WeilPrimeDiscrepancyEstimateV1.discrepancy_eq_mathlib_v1
#print axioms AEGIS.WeilPrimeDiscrepancyEstimateV1.primeWeight_deriv_v1
#print axioms AEGIS.WeilPrimeDiscrepancyEstimateV1.prime_correlation_norm_le_discrepancy_integral_v1
#print axioms AEGIS.WeilPrimeDiscrepancyEstimateV1.discrepancy_prime_power_split_v1

#print axioms AEGIS.WeilPrimeDiscrepancyEstimateV1.abs_discrepancy_le_linear_v1
#print axioms AEGIS.WeilPrimeDiscrepancyEstimateV1.prime_correlation_elementary_bound_v1
