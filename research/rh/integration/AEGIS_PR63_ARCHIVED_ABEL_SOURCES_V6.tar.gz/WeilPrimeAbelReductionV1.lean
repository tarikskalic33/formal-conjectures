import WeilSignedPrimeFiniteSupportV1
import Mathlib.NumberTheory.AbelSummation

/-! Exact finite Abel reduction of the actual signed prime correlation.
No estimate for the Chebyshev discrepancy is assumed or concluded. -/
open Set Function MeasureTheory Complex
open scoped BigOperators ContDiff
set_option autoImplicit false
noncomputable section
namespace AEGIS.WeilPrimeAbelReductionV1
open AEGIS.WeilWidthArchCorrelationV25
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilSeparatedArchBridgeV31
open AEGIS.WeilSignedKernelReductionV1
open AEGIS.WeilSignedPrimeFiniteSupportV1
open AEGIS.WeilWindowExhaustionV1

def PrimeWeightV1 (g : WeilCompactSmoothGV1) (d x : ℝ) : ℂ :=
  (Real.exp (-Real.log x / 2) : ℂ) * logCorrelationV25 g (d - Real.log x)

def ChebyshevV1 (x : ℝ) : ℂ :=
  ∑ k ∈ Finset.Icc 0 ⌊x⌋₊, (ArithmeticFunction.vonMangoldt k : ℂ)

theorem correlation_contDiff_v1 (g : WeilCompactSmoothGV1) :
    ContDiff ℝ ∞ (logCorrelationV25 g) := by
  have heq : logCorrelationV25 g = fun u : ℝ =>
      (Real.exp (u / 2) : ℂ) * WeilAutocorrelationV1 g (Real.exp u) := by
    funext u
    exact logCorrelation_eq_autocorrelation_v25 g u
  rw [heq]
  exact ((Complex.ofRealCLM.contDiff.comp
    (Real.contDiff_exp.comp (contDiff_id.div_const 2))).mul
      ((weil_autocorrelation_contDiff_v1 g).comp Real.contDiff_exp))

theorem primeWeight_contDiffAt_v1 (g : WeilCompactSmoothGV1) (d x : ℝ)
    (hx : 0 < x) : ContDiffAt ℝ ∞ (PrimeWeightV1 g d) x := by
  unfold PrimeWeightV1
  have hl : ContDiffAt ℝ ∞ Real.log x := Real.contDiffAt_log.mpr (ne_of_gt hx)
  exact (Complex.ofRealCLM.contDiff.contDiffAt.comp x
    (Real.contDiff_exp.contDiffAt.comp x (hl.neg.div_const 2))).mul
    ((correlation_contDiff_v1 g).contDiffAt.comp x (contDiffAt_const.sub hl))

theorem primeWeight_zero_of_large_log_v1 (g : WeilCompactSmoothGV1)
    (L d x : ℝ) (hw : LogSupportIn g (-L) L)
    (hx : d + 2 * L < Real.log x) : PrimeWeightV1 g d x = 0 := by
  have hc := logCross_zero_outside g g (-L) L (-L) L (d - Real.log x)
    hw hw (Or.inl (by linarith))
  simpa [PrimeWeightV1, logCorrelationV25, AEGIS.WeilThreeBlockCrossPrimeV28.logCrossV28] using congrArg
    (fun z : ℂ => (Real.exp (-Real.log x / 2) : ℂ) * z) hc

theorem prime_correlation_eq_finite_weight_sum_v1 (g : WeilCompactSmoothGV1)
    (d : ℝ) (N : ℕ) (hcut : ∀ n : ℕ, N ≤ n → SignedPrimeTermV1 g d n = 0) :
    SignedPrimeCorrelationV1 g d =
      ∑ k ∈ Finset.Icc 0 N, PrimeWeightV1 g d k *
        (ArithmeticFunction.vonMangoldt k : ℂ) := by
  have hsum : SignedPrimeCorrelationV1 g d =
      ∑ n ∈ Finset.range N, SignedPrimeTermV1 g d n := by
    change (∑' n, SignedPrimeTermV1 g d n) = _
    apply tsum_eq_sum
    intro n hn
    exact hcut n (Nat.le_of_not_gt (by simpa using hn))
  rw [hsum, ← Nat.range_succ_eq_Icc_zero, Finset.sum_range_succ']
  simp only [ArithmeticFunction.map_zero, Complex.ofReal_zero, mul_zero, add_zero, Nat.cast_zero]
  apply Finset.sum_congr rfl
  intro n _
  simp only [SignedPrimeTermV1, PrimeWeightV1, Nat.cast_add, Nat.cast_one]
  rw [show -Real.log ((n : ℝ) + 1) + d = d - Real.log ((n : ℝ) + 1) by ring]
  ring

theorem prime_correlation_abel_v1 (g : WeilCompactSmoothGV1) (d : ℝ) :
    ∃ N : ℕ, 1 ≤ N ∧ PrimeWeightV1 g d N = 0 ∧
      SignedPrimeCorrelationV1 g d =
        -(∫ x in Set.Ioc (1 : ℝ) N, deriv (PrimeWeightV1 g d) x * ChebyshevV1 x) := by
  obtain ⟨L, hL, hw⟩ := logLift_has_finite_window_v1 g
  obtain ⟨N, hN⟩ := exists_nat_gt (max 1 (Real.exp (d + 2 * L)))
  have hN1 : (1 : ℝ) < N := lt_of_le_of_lt (le_max_left _ _) hN
  have hNnat : 1 ≤ N := by exact_mod_cast hN1.le
  have hlog (x : ℝ) (hx : (N : ℝ) ≤ x) : d + 2 * L < Real.log x := by
    have he : Real.exp (d + 2 * L) < x :=
      (lt_of_le_of_lt (le_max_right _ _) hN).trans_le hx
    simpa using Real.log_lt_log (Real.exp_pos _) he
  have hz := primeWeight_zero_of_large_log_v1 g L d N hw (hlog N le_rfl)
  have hcut : ∀ n : ℕ, N ≤ n → SignedPrimeTermV1 g d n = 0 := by
    intro n hn
    have hx : (N : ℝ) ≤ ((n + 1 : ℕ) : ℝ) := by exact_mod_cast hn.trans (Nat.le_succ n)
    have h := primeWeight_zero_of_large_log_v1 g L d (n + 1) hw (hlog _ (by simpa using hx))
    have heq : SignedPrimeTermV1 g d n =
        (ArithmeticFunction.vonMangoldt (n + 1) : ℂ) * PrimeWeightV1 g d (n + 1) := by
      simp only [SignedPrimeTermV1, PrimeWeightV1, Nat.cast_add, Nat.cast_one]
      rw [show -Real.log ((n : ℝ) + 1) + d = d - Real.log ((n : ℝ) + 1) by ring]
      ring
    rw [heq, h, mul_zero]
  have hd : ∀ x ∈ Set.Icc (1 : ℝ) N, DifferentiableAt ℝ (PrimeWeightV1 g d) x := by
    intro x hx
    exact (primeWeight_contDiffAt_v1 g d x (lt_of_lt_of_le zero_lt_one hx.1)).differentiableAt (by simp)
  have hc : ContinuousOn (deriv (PrimeWeightV1 g d)) (Set.Icc (1 : ℝ) N) := by
    intro x hx
    exact ((primeWeight_contDiffAt_v1 g d x (lt_of_lt_of_le zero_lt_one hx.1)).derivWithin
      (m := 0) (by simp)).continuousAt.continuousWithinAt
  have hi : IntegrableOn (deriv (PrimeWeightV1 g d)) (Set.Icc (1 : ℝ) N) volume := hc.integrableOn_Icc
  have ha := sum_mul_eq_sub_integral_mul₀' (fun n : ℕ =>
    (ArithmeticFunction.vonMangoldt n : ℂ)) (by simp) N hd hi
  refine ⟨N, hNnat, hz, ?_⟩
  rw [prime_correlation_eq_finite_weight_sum_v1 g d N hcut, ha, hz, zero_mul, zero_sub]
  rfl
end AEGIS.WeilPrimeAbelReductionV1
#print axioms AEGIS.WeilPrimeAbelReductionV1.correlation_contDiff_v1
#print axioms AEGIS.WeilPrimeAbelReductionV1.primeWeight_contDiffAt_v1
#print axioms AEGIS.WeilPrimeAbelReductionV1.primeWeight_zero_of_large_log_v1
#print axioms AEGIS.WeilPrimeAbelReductionV1.prime_correlation_eq_finite_weight_sum_v1
#print axioms AEGIS.WeilPrimeAbelReductionV1.prime_correlation_abel_v1
